import os
import torch
import torch.nn as nn
import networks
import nee as nee
from options import TrainOptions
from dataset import dataset_unpair

from Cooperative import AdGAN
from saver import Saver
import h5py
import random
import numpy as np
from torchvision.transforms import Compose, Resize, RandomCrop, CenterCrop, RandomHorizontalFlip, ToTensor, Normalize
from torchvision import datasets, transforms
from torch.autograd import Variable
from PIL import Image
from torchvision.utils import save_image
from torchsummary import summary
import time
from torch.nn import functional as F
from transformer import Transformer
from fpn_inception import FPNInceptionSig
from fpn_inception_simple import FPNInceptionSimpleSig

style = '/mnt/Bri/tobetested/0338.JPG'

loader = transforms.Compose([
    transforms.Resize([640,960]),  # 将加载的图像转变为指定的大小
    transforms.ToTensor()])  # 将图像转化为tensor
 

def image_loader(image_name):
    image = Image.open(image_name)
    image = Variable(loader(image))
    image = image.unsqueeze(0)
    return image

def mean(arg):
    sum_ = sum(arg)
    num = len(arg)
    return sum_ / num

def get_batch(x, x_bad, batch_size):
    index = random.sample(range(0,np.shape(x)[0]),batch_size)
    return x[index,:], x_bad[index,:]

def main():
    transforms = []
    transforms.append(Normalize(mean=[0.5, 0.5, 0.5], std=[0.5, 0.5, 0.5]))
    TransformData = Compose(transforms)
    print('\n--- load data ---')

    style_img = image_loader(style)

    name = ['1.png','2.png','3.png','4.png','5.png','6.png','7.png','8.png','9.png','10.png','11.png','12.png','13.png','14.png','15.png','16.png','17.png','18.png']
    namef = ['1.png','2.png','3.png','4.png','5.png','6.png','7.png','8.png','9.png','10.png','11.png','12.png','13.png','14.png','15.png','16.png','17.png','18.png']
    savep = '/mnt/Bri/Re/'
    savel = '/mnt/Bri/yuantu/'
    savef = '/mnt/Bri/liangdu/'

    print('\n--- load model ---')
    
    DecomNet = nee.DecomNet(4, 4, 0, in_channels=3)
    AdjustmentNet = FPNInceptionSimpleSig(norm_layer=nn.BatchNorm2d)
    DecomNet = DecomNet.cuda() 
    AdjustmentNet = AdjustmentNet.cuda() 
    
    checkpoint = torch.load('/mnt/Bri/checkpoint/RICG_epoch_400_InceptionSimple.pth')
    DecomNet.load_state_dict(checkpoint['DecomNet'])
    AdjustmentNet.load_state_dict(checkpoint['AdjustmentNet'])

    print('\n--- test ---')


    images_a = style_img.type(torch.FloatTensor).cuda().detach()

    R, L = DecomNet(images_a)
    
    R = R.detach() * 2 - 1
    L = L.detach() * 2 - 1
    Lv = 1.5 * (1 - L)
    Lad = AdjustmentNet(L,Lv)
    adjustLow = (R/2+0.5) * (Lad/2+0.5)
    
    img = R[0,:,:,:]/2 + 0.5
    img = img.cpu()
    save_image(img,os.path.join(savep,namef[0]))
    
    img = adjustLow[0,:,:,:]
    img = img.cpu()
    save_image(img,os.path.join(savef,namef[0]))
    
    img = Lad[0,:,:,:]/2 + 0.5
    img = img.cpu()
    save_image(img,os.path.join(savel,namef[0]))
    
    img = L[0,:,:,:]/2 + 0.5
    img = img.cpu()
    save_image(img,os.path.join(savel,namef[1]))

    return

if __name__ == '__main__':
    torch.backends.cudnn.enabled = False
    torch.autograd.set_detect_anomaly(True)
    main()