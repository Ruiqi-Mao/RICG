import torch
from options import TrainOptions
from dataset import dataset_unpair
#from AdjustmentC import AdGAN
from Cooperative import AdGAN
from saver import Saver
import h5py
import random
import numpy as np
from torchsummary import summary
#from fvcore.nn import FlopCountAnalysis, parameter_count_table

def mean(arg):
    sum_ = sum(arg)
    num = len(arg)
    return sum_ / num

def main():
  # parse options
    parser = TrainOptions()
    opts = parser.parse()
    
    print('\n--- load dataset ---')
    dataset = dataset_unpair(opts)
    train_loader = torch.utils.data.DataLoader(dataset, batch_size=opts.batch_size, shuffle=True, num_workers=opts.nThreads)

    print('\n--- load model ---')
    model = AdGAN(opts)
    model.setgpu(opts.gpu)
    if opts.resume is None:
        model.initialize()
        ep0 = -1
        total_it = 0
    else:
        ep0, total_it = model.resume(opts.resume)

    model.set_scheduler(opts, last_ep=ep0)
    ep0 += 1
    print('start the training at epoch %d'%(ep0))
    
    #num_params1 = sum(param.numel() for param in model.AdjustmentNet.parameters())
    #num_params2 = sum(param.numel() for param in model.dis.parameters())
    #print(num_params1 + num_params2)
    
    #summary(model.AdjustmentNet, (3, 320, 480))
    #summary(model.dis, (3, 320, 480))
    
    #tensor = (torch.rand(1, 3, 320, 480),)

# 分析FLOPs
    #flops = FlopCountAnalysis(model.AdjustmentNet, tensor)
    #print("FLOPs: ", flops.total())
    
    saver = Saver(opts)
    #loader = transforms.Compose([transforms.Normalize(mean=[0.5, 0.5, 0.5], std=[0.5, 0.5, 0.5])])
  # train
    print('\n--- train ---')
    max_it = 500000
    for ep in range(ep0, opts.n_ep):
        L1 = []
        L2 = []
        L3 = []
        L4 = []
        L5 = []
        L6 = []
        L7 = []
        L8 = []
        L9 = []
        L10 = []
        L11 = []
        L12 = []
        L13 = []
        L14 = []
        L15 = []
        for it, (images_a, images_b) in enumerate(train_loader):
            if images_a.size(0) != opts.batch_size or images_b.size(0) != opts.batch_size:
                continue
            #images_aa = loader(images_a)
            #images_bb = loader(images_b)
            
            images_a = images_a.type(torch.FloatTensor).cuda(opts.gpu).detach()
            images_b = images_b.type(torch.FloatTensor).cuda(opts.gpu).detach()            
            #images_aa = images_aa.type(torch.FloatTensor).cuda(opts.gpu).detach()
            #images_bb = images_bb.type(torch.FloatTensor).cuda(opts.gpu).detach()
            
            if ep < 40:
                cgame = 4
            else:
                cgame = 4
            if (it + 1) % cgame != 0 and it < len(train_loader) - 2:
                
                model.EnhanceNet.eval()
                model.DecomNet.eval()
                
                model.update_G(images_a, images_b, it + 1)
                
                L1.append(model.CoLoss)
                L2.append(model.IsSmooth)
                L3.append(model.featureLoss)
                L4.append(model.loss_G_GAN)
                model.EnhanceNet.train()
                model.DecomNet.train()
                model.update_E(images_a, images_b, it + 1)
                model.update_H(images_a, images_b, it + 1)
                
                continue
            else:
                model.EnhanceNet.eval()
                model.DecomNet.eval()
                
                model.update_D(images_a, images_b, it + 1)
                L5.append(model.lossD)
                #model.EnhanceNet.train()
                #model.DecomNet.train()
                #model.update_E(images_a, images_b, it + 1)
                #model.update_H(images_a, images_b, it + 1)
            total_it += 1
        print('total_it: %d (ep %d, it %d), lr %08f, BriLoss %04f, IsSmooth %04f, featureLoss %04f, GANLoss %04f, DLoss %04f' % (total_it, ep, it, model.optimizer_G.param_groups[0]['lr'],mean(L1), mean(L2), mean(L3), mean(L4), mean(L5) ))
    # decay learning rate
        if opts.n_ep_decay > -1:
            model.update_lr()

    # save result image
        saver.write_img(ep, model)

    # Save network weights
        saver.write_model(ep, total_it, model)

    return

if __name__ == '__main__':
    torch.backends.cudnn.enabled = False
    torch.autograd.set_detect_anomaly(True)
    main()