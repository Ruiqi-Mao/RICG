from collections import OrderedDict
import torch
import torch.nn as nn
from torch.nn import init
import functools
from torch.autograd import Variable
import numpy as np
from torchvision import models
from torch.optim import lr_scheduler
import torch.nn.functional as F
from transformer import Transformer
from einops import rearrange

class BasicUnit(nn.Module):
    def __init__(self, channels: int, dropout: float):
        super(BasicUnit, self).__init__()
        self.block = nn.Sequential(OrderedDict([
            ("2_convolution", nn.Conv2d(channels, channels, (3, 3), stride=1, padding=1, bias=True)),
            ("2_batchnorm", nn.BatchNorm2d(channels)),
            ("1_activation", nn.LeakyReLU(0.2,True)),
        ]))

    def forward(self, x):
        return x + self.block(x)

class UpsampleUnit(nn.Module):
    def __init__(self, in_channels: int, out_channels: int, stride: int, dropout: float):
        super(UpsampleUnit, self).__init__()
        self.block = nn.Sequential(OrderedDict([
            ("0_upsampling", nn.ConvTranspose2d(in_channels, out_channels, (3, 3), stride=stride, padding=1, output_padding=1, bias=True)),
            ("2_activation", nn.LeakyReLU(0.2,True)),
        ]))
    def forward(self, x):
        return self.block(x)

class DownsampleUnit(nn.Module):
    def __init__(self, in_channels: int, out_channels: int, stride: int, dropout: float):
        super(DownsampleUnit, self).__init__()
        self.block = nn.Sequential(OrderedDict([
            ("0_convolution", nn.Conv2d(in_channels, out_channels, (3, 3), stride=stride, padding=1, bias=False)),
            ("2_activation", nn.LeakyReLU(0.2,True)),
        ]))

    def forward(self, x):
        return self.block(x)
class DownsampleUnitEn(nn.Module):
    def __init__(self, in_channels: int, out_channels: int, stride: int, dropout: float):
        super(DownsampleUnitEn, self).__init__()
        self.block = nn.Sequential(OrderedDict([
            ("0_convolution", nn.Conv2d(in_channels, out_channels, (3, 3), stride=stride, padding=1, bias=True)),
            ("2_batchnorm", nn.BatchNorm2d(out_channels)),
            ("2_activation", nn.LeakyReLU(0.2,True)),
        ]))

    def forward(self, x):
        return self.block(x)

class Block(nn.Module):
    def __init__(self, in_channels: int, out_channels: int, stride: int, depth: int, dropout: float):
        super(Block, self).__init__()
        self.block = nn.Sequential(
            DownsampleUnit(in_channels, out_channels, stride, dropout),
            *(BasicUnit(out_channels, dropout) for _ in range(depth))
        )

    def forward(self, x):
        return self.block(x)

class Up_Block(nn.Module):
    def __init__(self, in_channels: int, out_channels: int, stride: int, depth: int, dropout: float):
        super(Up_Block, self).__init__()
        self.upblock = nn.Sequential(
            UpsampleUnit(in_channels, out_channels, stride, dropout),
            *(BasicUnit(out_channels, dropout) for _ in range(depth))
        )

    def forward(self, x):
        return self.upblock(x)

class AdNet(nn.Module):
    def __init__(self, depth: int, width_factor: int, dropout: float, in_channels: int):
        super(AdNet, self).__init__()

        self.filters = [16, 32, 64, 128, 9 * 16 * width_factor]
        self.block_depth = (depth - 4)//(3*2)

        self.f = nn.Sequential(OrderedDict([
            ("0_convolution", nn.Conv2d(in_channels, self.filters[0], (7, 7), stride=1, padding=3, bias=True)),
            ("1_block", Block(self.filters[0], self.filters[1], 1, self.block_depth, dropout)),
            ("2_block", Block(self.filters[1], self.filters[2], 1, self.block_depth, dropout)),
            ("3_block", Block(self.filters[2], self.filters[3], 1, self.block_depth, dropout)),
            ("4_block", Block(self.filters[3], 3, 1, self.block_depth, dropout)),
            ("0r_convolution", nn.Tanh()),
        ]))

    def forward(self, x, xv):
        for i in range(5):
            res = self.f(x)
            x = x + xv * res
        return x

class EnhanceNetwork(nn.Module):
    def __init__(self, layers, channels):
        super(EnhanceNetwork, self).__init__()

        kernel_size = 3
        dilation = 1
        padding = int((kernel_size - 1) / 2) * dilation

        self.in_conv = nn.Sequential(
            nn.Conv2d(in_channels=3, out_channels=channels, kernel_size=kernel_size, stride=1, padding=padding),
            nn.ReLU()
        )

        self.conv = nn.Sequential(
            nn.Conv2d(in_channels=channels, out_channels=channels, kernel_size=kernel_size, stride=1, padding=padding),
            nn.InstanceNorm2d(channels),
            nn.ReLU()
        )

        self.blocks = nn.ModuleList()
        for i in range(layers):
            self.blocks.append(self.conv)

        self.out_conv = nn.Sequential(
            nn.Conv2d(in_channels=channels, out_channels=3, kernel_size=3, stride=1, padding=1),
            nn.Sigmoid()
        )

    def forward(self, input):
        fea = self.in_conv(input)
        for conv in self.blocks:
            fea = fea + conv(fea)
        fea = self.out_conv(fea)

        illu = fea + input
        illu = torch.clamp(illu, 0.0001, 1)

        return illu 
    
class DecomNet(nn.Module):
    def __init__(self, depth: int, width_factor: int, dropout: float, in_channels: int):
        super(DecomNet, self).__init__()

        self.filters = [16, 32, 64, 128, 9 * 16 * width_factor]
        self.block_depth = (depth - 4)//(3*2)
        self.Inet = EnhanceNetwork(3,32)
        self.f = nn.Sequential(OrderedDict([
            ("0_convolution", nn.Conv2d(in_channels, self.filters[0], (7, 7), stride=1, padding=3, bias=True)),
            ("1_block", Block(self.filters[0], self.filters[1], 1, self.block_depth, dropout)),
            ("2_block", Block(self.filters[1], self.filters[2], 1, self.block_depth, dropout)),
            #("3_block", Block(self.filters[2], self.filters[3], 1, self.block_depth, dropout)),
            ("4_block", Block(self.filters[2], 3, 1, self.block_depth, dropout)),
            ("0r_convolution", nn.Sigmoid()),
        ]))

    def forward(self, x):
        #out = self.f(x)
        #R = out
        L = self.Inet(x)
        R = torch.clamp(x / L, 0, 1)
        #R = x + self.f(x)
        #L = torch.cat((L,L,L), 1)
        return R, L
    
class DecomNetC(nn.Module):
    def __init__(self, depth: int, width_factor: int, dropout: float, in_channels: int):
        super(DecomNetC, self).__init__()

        self.filters = [16, 32, 64, 128, 9 * 16 * width_factor]
        self.block_depth = (depth - 4)//(3*2)
        self.Inet = EnhanceNetwork(3,32)
        self.f = nn.Sequential(OrderedDict([
            ("0_convolution", nn.Conv2d(in_channels, self.filters[0], (7, 7), stride=1, padding=3, bias=True)),
            ("1_block", Block(self.filters[0], self.filters[1], 1, self.block_depth, dropout)),
            ("2_block", Block(self.filters[1], self.filters[2], 1, self.block_depth, dropout)),
            ("4_block", Block(self.filters[2], 3, 1, self.block_depth, dropout)),
            ("0r_convolution", nn.Sigmoid()),
        ]))

    def forward(self, x):
        L = self.Inet(x)
        R = x + self.f(x)
        return R, L
    
class DecomNetS(nn.Module):
    def __init__(self, depth: int, width_factor: int, dropout: float, in_channels: int):
        super(DecomNetS, self).__init__()

        self.filters = [16, 32, 64, 128, 9 * 16 * width_factor]
        self.block_depth = (depth - 4)//(3*2)

        self.f = nn.Sequential(OrderedDict([
            ("0_convolution", nn.Conv2d(in_channels, self.filters[0], (7, 7), stride=1, padding=3, bias=True)),
            ("1_block", Block(self.filters[0], self.filters[1], 1, self.block_depth, dropout)),
            ("2_block", Block(self.filters[1], 4, 1, self.block_depth, dropout)),
            #("3_block", Block(self.filters[2], self.filters[3], 1, self.block_depth, dropout)),
            #("4_block", Block(self.filters[3], 4, 1, self.block_depth, dropout)),
            ("0r_convolution", nn.Sigmoid()),
        ]))

    def forward(self, x):
        out = self.f(x)
        R = out[:,0:3,:,:]
        L = out[:,3:4,:,:]
        L = torch.cat((L,L,L), 1)
        return R, L
    
class NRNBM(nn.Module):
    def __init__(self, depth: int, width_factor: int, dropout: float, in_channels: int):
        super(NRNBM, self).__init__()

        self.filters = [16, 32, 64, 128, 9 * 16 * width_factor]
        self.block_depth = (depth - 4)//(3*2)

        self.f = nn.Sequential(OrderedDict([
            ("0_convolution", nn.Conv2d(in_channels, self.filters[0], (7, 7), stride=1, padding=3, bias=True)),
            ("1_block", Block(self.filters[0], self.filters[1], 1, self.block_depth, dropout)),
            ("2_block", Block(self.filters[1], self.filters[2], 1, self.block_depth, dropout)),
            ("3_block", Block(self.filters[2], self.filters[3], 1, self.block_depth, dropout)),
            ("4_block", Block(self.filters[3], 36, 1, self.block_depth, dropout)),
            ("0r_convolution", nn.Sigmoid()),
        ]))

    def forward(self, x):
        out = self.f(x)
        a1,a2,a3,a4,a5,a6, a7,a8,a9,a10,a11,a12 = torch.split(out, 3, dim=1)
        x = (1 - a1) * torch.sin(3.1415926*0.5*x) + a1 * x
        res1 = x
        x = (1 - a2) * torch.sin(3.1415926*0.5*x) + a2 * x
        res2 = x
        x = (1 - a3) * torch.sin(3.1415926*0.5*x) + a3 * x
        res3 = x
        x = (1 - a4) * torch.sin(3.1415926*0.5*x) + a4 * x
        res4 = x
        x = (1 - a5) * torch.sin(3.1415926*0.5*x) + a5 * x
        res5 = x
        x = (1 - a6) * torch.sin(3.1415926*0.5*x) + a6 * x
        res6 = x
        x = (1 - a7) * torch.sin(3.1415926*0.5*x) + a7 * x
        res7 = x
        x = (1 - a8) * torch.sin(3.1415926*0.5*x) + a8 * x
        res8 = x
        x = (1 - a9) * torch.sin(3.1415926*0.5*x) + a9 * x
        res9 = x
        x = (1 - a10) * torch.sin(3.1415926*0.5*x) + a10 * x
        res10 = x
        x = (1 - a11) * torch.sin(3.1415926*0.5*x) + a11 * x
        res11 = x
        x = (1 - a12) * torch.sin(3.1415926*0.5*x) + a12 * x
        res12 = x
        return res1, res2, res3, res4, res5, res6, res7, res8, res9, res10, res11, res12, out
    
class NRNBMStar(nn.Module):
    def __init__(self, in_channels, norm_layer):
        super(NRNBMStar, self).__init__()
        self.block0 = nn.Sequential(
            nn.Conv2d(in_channels, 32, kernel_size=3, padding=1),
            norm_layer(32),
            nn.ReLU(),
        )
        self.block1 = nn.Sequential(
            nn.Conv2d(32, 12, kernel_size=3, padding=1),
            norm_layer(12),
            nn.ReLU(),
        )
        self.transformer = Transformer(12, 1, 4, 64, 0)

    def forward(self, x):
        n, c, h, w = x.shape
        x1 = self.block0(x)
        x1 = self.block1(x1)
        outman = x1
        x1 = nn.AdaptiveAvgPool2d((32, 32))(x1)

        trans_inp = rearrange(x1, 'b c  h w -> b (  h w)  c ')
        x_out = self.transformer(trans_inp)
        x_r = rearrange(x_out, 'b (h w) c -> b  c  h w', h=32)
        out = F.upsample_bilinear(x_r, (h, w)).tanh()
        
        flabel = []

        a1,a2,a3,a4 = torch.split(out, 3, dim=1)
        x = (1 - a1) * torch.sin(3.1415926*0.5*x) + a1 * x
        flabel.append(x)
        x = (1 - a2) * torch.sin(3.1415926*0.5*x) + a2 * x
        flabel.append(x)
        x = (1 - a3) * torch.sin(3.1415926*0.5*x) + a3 * x
        flabel.append(x)
        x = (1 - a4) * torch.sin(3.1415926*0.5*x) + a4 * x
        flabel.append(x)

        return flabel, out
    
class AdNetI(nn.Module):
    def __init__(self, depth = 1, width_factor = 4, dropout = 0, in_channels = 3):
        super(AdNetI, self).__init__()

        self.filters = [16, 32, 64, 128, 9 * 16 * width_factor]
        self.block_depth = depth

        self.f = nn.Sequential(OrderedDict([
            ("0_convolution", nn.Conv2d(in_channels, self.filters[0], (7, 7), stride=1, padding=3, bias=True)),
            ("1_block", Block(self.filters[0], self.filters[1], 1, self.block_depth, dropout)),
            ("2_block", Block(self.filters[1], self.filters[2], 1, self.block_depth, dropout)),
            ("4_block", Block(self.filters[2], 1, 1, self.block_depth, dropout)),
            ("0r_convolution", nn.Tanh()),
        ]))

    def forward(self, x):
        #ori = x
        x = self.f(x)
        x = torch.cat((x,x,x), 1)
        out = x
        return out
    
class AdNetR(nn.Module):
    def __init__(self, depth = 1, width_factor = 4, dropout = 0, in_channels = 3):
        super(AdNetR, self).__init__()

        self.filters = [16, 32, 64, 128, 9 * 16 * width_factor]
        self.block_depth = depth

        self.f = nn.Sequential(OrderedDict([
            #("0_norm", nn.BatchNorm2d(in_channels)),
            ("0_convolution", nn.Conv2d(in_channels, self.filters[0], (7, 7), stride=1, padding=3, bias=True)),
            ("1_block", Block(self.filters[0], self.filters[1], 1, self.block_depth, dropout)),
            ("2_block", Block(self.filters[1], self.filters[2], 1, self.block_depth, dropout)),
            ("4_block", Block(self.filters[2], 3, 1, self.block_depth, dropout)),
            ("0r_convolution", nn.Tanh()),
        ]))

    def forward(self, x):
        ori = x
        x = self.f(x)
        out = x + ori
        return out