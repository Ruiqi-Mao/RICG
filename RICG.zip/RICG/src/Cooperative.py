import networks as networks
import nee as nee
import torch
import torch.nn as nn
import itertools
from torch.nn import functional as F
from torchvision import datasets, transforms
from PIL import Image
from torch.autograd import Variable 
from fpn_inception import FPNInceptionSig
from fpn_inception_simple import FPNInceptionSimpleSig
import numpy as np
import torchfile
import random
#from function import exact_feature_distribution_matching as efdm

class AdGAN(nn.Module):
    def __init__(self, opts):
        super(AdGAN, self).__init__()
    # parameters
        lr = 0.0001
        self.nz = 8
        self.EnhanceNet = nee.NRNBMStar(in_channels=3, norm_layer=nn.BatchNorm2d)
        self.DecomNet = nee.DecomNet(4, 4, 0, in_channels=3)
        self.local = 1

        self.dis = networks.MultiScaleDis(input_dim = 3)
        self.disC = networks.Dis(input_dim = 3)
        
        self.trans = networks.RGB_HSV()
   
        self.BriLoss = networks.L_bri(patch_size = 32, mean_val = 0.5)
        self.BriLoss1 = networks.L_bri(patch_size = 32, mean_val = 0.6)

        self.use_wgan = 0
        #self.AdjustmentNet = FPNInceptionSig(norm_layer=nn.BatchNorm2d)
        self.AdjustmentNet = FPNInceptionSimpleSig(norm_layer=nn.BatchNorm2d)
        if self.use_wgan:
            self.criterionGAN = networks.DiscLossWGANGP()
        else:
            self.criterionGAN = networks.GANLoss(use_lsgan=False)
        self.criterionGANLS = networks.GANLoss()

        self.ColorLossF = networks.L_color()
        self.DuibiLoss = networks.L_spa()
        self.ColorLoss = networks.L_color_cs()
        self.PLoss = networks.VGGLoss()
        self.PCLoss = networks.VGGLossCos()
        self.TVVLoss = networks.SmoothLossNew()
        self.TVLoss = networks.L_TV()
        self.Grad = networks.Gradient_Net()
        self.norm = nn.InstanceNorm2d(512, affine=False)
        self.norm1 = nn.InstanceNorm2d(128, affine=False)
        self.norm2 = nn.InstanceNorm2d(256, affine=False)
        self.pool = nn.AvgPool2d(kernel_size=3, stride=1, padding=1)
        self.pool7 = nn.AvgPool2d(kernel_size=7, stride=1, padding=3)
        pretrained_vgg = torchfile.load('/mnt/Bri/premodel/vgg_normalised_conv4_1.t7')
        self.vggmap = networks.VGGEncoder(vgg = pretrained_vgg)
        for param in self.vggmap.parameters():
            param.requires_grad = False
                
        self.optimizer_G = torch.optim.Adam(self.AdjustmentNet.parameters(), lr=lr, betas=(0.5, 0.999), weight_decay=0.0001)
        self.optimizer_D = torch.optim.Adam(itertools.chain(self.dis.parameters(), self.disC.parameters()), lr=lr, betas=(0.5, 0.999), weight_decay=0.0001)
        self.optimizer_E = torch.optim.Adam(self.EnhanceNet.parameters(), lr=lr, betas=(0.5, 0.999), weight_decay=0.0001)
        self.optimizer_H = torch.optim.Adam(self.DecomNet.parameters(), lr=lr*10, betas=(0.5, 0.999), weight_decay=0.0001)
    
    def initialize(self):  
        self.EnhanceNet.apply(networks.gaussian_weights_init)
        self.DecomNet.apply(networks.gaussian_weights_init)
        self.dis.apply(networks.gaussian_weights_init)
        self.disC.apply(networks.gaussian_weights_init)

    def set_scheduler(self, opts, last_ep=0):
        self.optimizer_G_sch = networks.get_scheduler(self.optimizer_G, opts, last_ep)
        self.optimizer_D_sch = networks.get_scheduler(self.optimizer_D, opts, last_ep)
        self.optimizer_E_sch = networks.get_scheduler(self.optimizer_E, opts, last_ep)
        self.optimizer_H_sch = networks.get_scheduler(self.optimizer_H, opts, last_ep)

    def L1_loss(self,x,y):
        return torch.mean(torch.abs(x-y))
    
    def L2_loss(self,x,y):
        return torch.mean(torch.pow(x-y, 2))

    def setgpu(self, gpu):
        self.gpu = gpu
        self.DecomNet.cuda(self.gpu)
        self.EnhanceNet.cuda(self.gpu)
        self.AdjustmentNet.cuda(self.gpu)
        self.dis.cuda(self.gpu)
        self.disC.cuda(self.gpu)
        self.EnhanceNet.cuda(self.gpu)
        #self.EnhanceNet.eval()
        self.vggmap.cuda(self.gpu)
        #self.enc_a.cuda(self.gpu)
        self.criterionGANLS.cuda(self.gpu)

    def get_z_random(self, batchSize, nz, random_type='gauss'):
        z = torch.randn(batchSize, nz).cuda(self.gpu)
        return z   
    def median_filter(self, images, kernel_size):
        padding = kernel_size // 2
        images_padded = F.pad(images, (padding, padding, padding, padding), mode='reflect')

        unfolded = images_padded.unfold(2, kernel_size, 1).unfold(3, kernel_size, 1)
        #print(unfolded.shape)
        unfolded = unfolded.contiguous().view(images.shape[0], images.shape[2] * images.shape[3], 3, kernel_size * kernel_size)
    
        median_r = torch.median(unfolded[:, :, 0], dim=2)[0]
        median_g = torch.median(unfolded[:, :, 1], dim=2)[0]
        median_b = torch.median(unfolded[:, :, 2], dim=2)[0]

        filtered_images = torch.stack((median_r, median_g, median_b), dim=2)
        filtered_images = filtered_images.view(images.shape[0], 3, images.shape[2], images.shape[3])

        return filtered_images    
    def patch2D(self, x, k, patchSize):
        w = x.size(3)
        h = x.size(2)
        patch = []
        for i in range(k):
            w_offset_1 = random.randint(0, max(0, w - patchSize - 1))
            h_offset_1 = random.randint(0, max(0, h - patchSize - 1))
            p = x[:,:, h_offset_1:h_offset_1 + patchSize, w_offset_1:w_offset_1 + patchSize]
            patch.append(p)
        return patch
    
    def patch2Dpair(self, x, y, k, patchSize):
        w = x.size(3)
        h = x.size(2)
        patchx = []
        patchy = []
        for i in range(k):
            w_offset_1 = random.randint(0, max(0, w - patchSize - 1))
            h_offset_1 = random.randint(0, max(0, h - patchSize - 1))
            px = x[:,:, h_offset_1:h_offset_1 + patchSize, w_offset_1:w_offset_1 + patchSize]
            patchx.append(px)
            py = y[:,:, h_offset_1:h_offset_1 + patchSize, w_offset_1:w_offset_1 + patchSize]
            patchy.append(py)
        return patchx, patchy
    
    def vgg_preprocess(self, batch):
        tensortype = type(batch.data)
        (r, g, b) = torch.chunk(batch, 3, dim = 1)
        batch = torch.cat((b, g, r), dim = 1) # convert RGB to BGR
        batch = (batch + 1) * 255 * 0.5 # [-1, 1] -> [0, 255]

        mean = tensortype(batch.data.size())
        mean[:, 0, :, :] = 103.939
        mean[:, 1, :, :] = 116.779
        mean[:, 2, :, :] = 123.680
        batch = batch.sub(Variable(mean).cuda()) # subtract mean
        return batch
    
    def PerceptualLoss(self, x, y):
        x = self.vgg_preprocess(x)
        y = self.vgg_preprocess(y)
        
        #PLos1 = self.L1_loss(self.norm(self.vggmap(x, 4)), efdm(self.norm(self.vggmap(x, 4)), self.norm(self.vggmap(y, 4))))
        #PLos2 = self.L1_loss(self.norm2(self.vggmap(x, 3)), efdm(self.norm2(self.vggmap(x, 3)), self.norm2(self.vggmap(y, 3))))
        #PLos3 = self.L1_loss(self.norm1(self.vggmap(x, 2)), efdm(self.norm1(self.vggmap(x, 2)), self.norm1(self.vggmap(y, 2))))
        #return PLos1 + PLos2 + PLos3
        return self.L1_loss(self.norm(self.vggmap(x, 4)), self.norm(self.vggmap(y, 4))) + self.L1_loss(self.norm2(self.vggmap(x, 3)), self.norm2(self.vggmap(y, 3))) + self.L1_loss(self.norm1(self.vggmap(x, 2)), self.norm1(self.vggmap(y, 2)))
    
    def PerceptualLossk(self, x, y):
        x = self.vgg_preprocess(x)
        y = self.vgg_preprocess(y)
        
        return self.L1_loss(self.norm(self.vggmap(x, 4)), self.norm(self.vggmap(y, 4)))
    
    def PerceptualCosLoss(self, x, y):
        x = self.vgg_preprocess(x)
        y = self.vgg_preprocess(y)
        
        return torch.mean(1 - torch.nn.functional.cosine_similarity(self.norm1(self.vggmap(x, 2)), self.norm1(self.vggmap(y, 2)), dim = 1))
    
    def forwardE(self, input_low, input_normal):
        self.L = input_low
        self.real_N = input_normal
        
        self.flabel, self.Map = self.EnhanceNet(self.L)
        
    def forwardH(self, input_low, input_normal):
        self.L = input_low
        self.real_N = input_normal
        
        self.flabel, self.Map = self.EnhanceNet(self.L)

        self.low = self.L
        self.Rc = []
        self.Lc = []
        for i in range(len(self.flabel)):
            R, L = self.DecomNet(self.flabel[i].detach())
            self.Rc.append(R)
            self.Lc.append(L)   
            
    def forward(self, input_low, input_normal):
        self.low = input_low
        self.nor = input_normal
        
        #self.flabelk, _ = self.EnhanceNet(self.low)
        
        self.R, self.L = self.DecomNet(self.low)
        _, self.Lnor = self.DecomNet(self.nor)
        _, self.Lstd = self.DecomNet(self.median_filter(self.R,3))
        self.low = self.low * 2 - 1
        self.nor = self.nor * 2 - 1

        self.R = self.R.detach() * 2 - 1
        self.L = self.L.detach() * 2 - 1
        self.Lstd = self.Lstd.detach() * 2 - 1
        #self.Lv = 1 - self.trans.rgb_to_hsv(self.L)[:,2:3,:,:]
        #self.Lv = torch.pow(self.Lv, 1/3)
        #self.Lv = torch.cat((self.Lv,self.Lv,self.Lv), dim = 1)
    
        self.Lv = 1 * (1 - self.L)
        #self.L = self.L * 2 - 1
        
        self.Lad = self.AdjustmentNet(self.L,self.Lv)
        self.adjustLow = (self.R/2+0.5) * (self.Lad/2+0.5)
        #self.adjustLow = self.R * self.Lad
        self.adjustLow = self.adjustLow * 2 - 1
        
        if self.local == 1:
            self.Lnor = self.Lnor.detach() * 2 - 1       

            self.Lpatch, self.Ladpatch = self.patch2Dpair(self.Lstd, self.Lad, 5, 80)
            self.lowpatch, self.adjustpatch = self.patch2Dpair(self.low, self.adjustLow, 5, 80)
            self.Lnorpatch = self.patch2D(self.Lnor, 5, 80)
            self.norpatch = self.patch2D(self.nor, 5, 80)
            #self.Rpatch, self.adjustpatchR = self.patch2Dpair(self.R, self.adjustLow, 6, 80)
        
    def info(self, x, mu, var):
        logli = -0.5*(var.mul(2*np.pi)+1e-6).log() - \
                (x-mu).pow(2).div(var.mul(2.0)+1e-6)
    
        return logli.sum(1).mean().mul(-1)  
    
    def maxRGB(self, x):
        maxx, _ = torch.max(x, dim = 1, keepdims = True)
        return torch.cat((self.pool(maxx),self.pool(maxx),self.pool(maxx)), dim = 1)

    def PearsonLoss(self, x, y):
        x = x.view(x.size(0),-1)
        y = y.view(y.size(0),-1)
        ex = torch.mean(x)
        ey = torch.mean(y)
        
        ex2 = torch.mean(x**2)
        ey2 = torch.mean(y**2)
        
        xy = x * y
        exy = torch.mean(xy)
        
        numerator = exy - ex * ey                                 
        denominator = torch.sqrt(ex2-ex**2) * torch.sqrt(ey2-ey**2) + 1e-6
        rhoXY = torch.abs(numerator/denominator)
        return torch.exp(-10*rhoXY)
    
    def backward_D(self, netD, real, fake):
        pred_fake = netD.forward(fake.detach())
        pred_real = netD.forward(real)
        loss_D = 0
        for it, (out_a, out_b) in enumerate(zip(pred_fake, pred_real)):
            out_fake = out_a
            out_real = out_b
            all0 = torch.zeros_like(out_fake).cuda(self.gpu)
            all1 = torch.ones_like(out_real).cuda(self.gpu)
            ad_fake_loss = self.L2_loss(out_fake, all0)
            ad_true_loss = self.L2_loss(out_real, all1)
            loss_D += ad_true_loss + ad_fake_loss
        return loss_D
    
    def backward_D_basic(self, netD, real, fake, use_ragan = True):
        # Real
        pred_real = netD.forward(real)
        pred_fake = netD.forward(fake.detach())
        if self.use_wgan:
            loss_D_real = pred_real.mean()
            loss_D_fake = pred_fake.mean()
            loss_D = loss_D_fake - loss_D_real + self.criterionGAN.calc_gradient_penalty(netD, 
                                                real.data, fake.data)
        elif use_ragan:
            loss_D = (self.criterionGAN(pred_real - torch.mean(pred_fake), True) +
                                      self.criterionGAN(pred_fake - torch.mean(pred_real), False)) / 2
        else:
            loss_D_real = self.criterionGANLS(pred_real, True)
            loss_D_fake = self.criterionGANLS(pred_fake, False)
            loss_D = (loss_D_real + loss_D_fake) * 0.5
        return loss_D
    
    def backward_D_basic_patch(self, netD, real, fake):
        # Real
        loss_D = 0
        for i in range(len(real)):
            pred_real = netD.forward(real[i])
            pred_fake = netD.forward(fake[i].detach())

            loss_D_real = self.criterionGANLS(pred_real, True)
            loss_D_fake = self.criterionGANLS(pred_fake, False)
            loss_D += (loss_D_real + loss_D_fake) * 0.5
        return loss_D / 1
    
    def backward_G_GAN_basic(self, real, fake, netD, use_ragan = True):
        pred_fake = netD.forward(fake)
        if self.use_wgan:
            loss_G_A = -pred_fake.mean()
        elif use_ragan:
            pred_real = netD.forward(real)

            loss_G_A = (self.criterionGAN(pred_real - torch.mean(pred_fake), False) +
                                      self.criterionGAN(pred_fake - torch.mean(pred_real), True)) / 2
            
        else:
            loss_G_A = self.criterionGANLS(pred_fake, True)
        return loss_G_A
    
    def backward_G_GAN_basic_patch(self, fake, netD):
        loss_G_A = 0
        for i in range(len(fake)):
            pred_fake = netD.forward(fake[i])
            loss_G_A += self.criterionGANLS(pred_fake, True)
        return loss_G_A
    
    def backward_D_patch(self, netD, real, fake):
        loss_D = 0
        for i in range(len(real)):
            pred_fake = netD.forward(fake[i].detach())
            pred_real = netD.forward(real[i])
            for it, (out_a, out_b) in enumerate(zip(pred_fake, pred_real)):
                out_fake = out_a
                out_real = out_b
                all0 = torch.zeros_like(out_fake).cuda(self.gpu)
                all1 = torch.ones_like(out_real).cuda(self.gpu)
                ad_fake_loss = self.L2_loss(out_fake, all0)
                ad_true_loss = self.L2_loss(out_real, all1)
                loss_D += ad_true_loss + ad_fake_loss
        return loss_D
    
    def backward_G_GAN(self, fake, netD):
        outs_fake = netD.forward(fake)
        loss_G = 0
        for out_a in outs_fake:
            o_fake = out_a
            all_ones = torch.ones_like(o_fake).cuda(self.gpu)
            loss_G += self.L2_loss(o_fake, all_ones)
        return loss_G
    
    def backward_G_GAN_patch(self, fake, netD):
        loss_G = 0
        for i in range(len(fake)):
            outs_fake = netD.forward(fake[i])
            for out_a in outs_fake:
                o_fake = out_a
                all_ones = torch.ones_like(o_fake).cuda(self.gpu)
                loss_G += self.L2_loss(o_fake, all_ones)
        return loss_G
    
    def backward_G_GAN_content(self, data):
        outs = self.disC.forward(data)
        ad_loss = 0
        for out in outs:
            outputs_fake = nn.functional.sigmoid(out)
            all_half = 0.5*torch.ones((outputs_fake.size(0))).cuda(self.gpu)
            ad_loss = nn.functional.binary_cross_entropy(outputs_fake, all_half)
        return ad_loss

    def backward_E(self):
        self.loss_E = 0
        for i in range(len(self.flabel)):
            self.CoLossE = self.ColorLossF(self.flabel[i])
            self.illLossE = self.BriLoss1(self.flabel[i])
            self.DbLossE = self.DuibiLoss(self.flabel[i], self.L)
            self.SmoothLossE = self.TVLoss(self.Map)
            #self.loss_E += self.CoLossE * 30 + self.illLossE * 10 + self.DbLossE * 20 + self.SmoothLossE * 50 * (1/len(self.flabel))#最终
            self.loss_E += self.CoLossE * 30 + self.illLossE * 20 + self.DbLossE * 50 + self.SmoothLossE * 10 * (1/len(self.flabel))#最终

        self.loss_E.backward()  
        
    def backward_H(self):
        self.loss_H = 0
        for i in range(len(self.flabel)):
            self.reconLossH = self.L1_loss(self.Rc[i] * self.Lc[i], self.flabel[i].detach())
            self.domainLossH = self.L1_loss(self.Lc[i], self.flabel[i].detach())
            self.IsSmoothH = self.TVVLoss(self.flabel[i].detach(), self.Lc[i])
            if i > 0:
                self.RlossH = self.L1_loss(self.Rc[i-1], self.Rc[i])
            else:
                self.RlossH = 0 
            self.loss_H += self.IsSmoothH * 0.25 + self.reconLossH * 1 + self.domainLossH * 1 + self.RlossH * 0.1#0.1
            
        self.loss_H.backward()
    
    def backward_G(self):
        self.CoLoss = 0
        self.IsSmooth = self.PerceptualLossk(self.adjustLow, self.R) * 1 
        self.IsSmooth += 1 * self.PerceptualLoss(self.Lad, self.Lstd)
        
        self.loss_G_GAN = 1 * self.backward_G_GAN(self.adjustLow, self.dis)# + self.backward_G_GAN(self.Rad, self.dis)
        if self.local == 1:
            self.loss_G_GAN += 1 * self.backward_G_GAN_patch(self.Ladpatch, self.disC) / len(self.Lpatch)
            
        self.featureLoss = 0
       
        self.loss_G = self.IsSmooth * 1 + self.loss_G_GAN * 1 #最佳25
        self.loss_G.backward()  
    
    def _l2_regularize(self, mu):
        mu_2 = torch.pow(mu, 2)
        encoding_loss = torch.mean(mu_2)
        return encoding_loss

    def clip_weight(self, model, clip_value=(-0.01, 0.01)):
        for param in model.parameters():
            param.data = torch.clip(param.data, min=clip_value[0], max=clip_value[1])

    def set_requires_grad(self, nets, requires_grad=False):
        if not isinstance(nets, list):
            nets = [nets]
            for net in nets:
                if net is not None:
                    for param in net.parameters():
                        param.requires_grad = requires_grad

    def update_lr(self):
        self.optimizer_G_sch.step()
        self.optimizer_D_sch.step()
        self.optimizer_E_sch.step()
        self.optimizer_H_sch.step()
        
    def update_D(self, image_a, image_b, k):
        self.forward(image_a, image_b)  
        self.set_requires_grad(self.dis, True)
        self.set_requires_grad(self.disC, True)
                                                              
        self.lossD = self.backward_D(self.dis, self.nor, self.adjustLow)
        if self.local == 1:
            self.lossD += self.backward_D_patch(self.disC, self.Lnorpatch, self.Ladpatch)
        self.lossD.backward()
        
        if k % 1 == 0:
            self.optimizer_D.step()    
            self.optimizer_D.zero_grad()
            #print('Optimized D!')
    def update_H(self, image_a, image_b, k): 
        self.forwardH(image_a, image_b)  

        self.optimizer_H.zero_grad()
        self.backward_H()
        #if k % 1 == 0:
        self.optimizer_H.step()
        #self.optimizer_H.zero_grad()
        #self.forward(image_a, image_b)  
        
    def update_E(self, image_a, image_b, k): 
        self.forwardE(image_a, image_b)  
        self.optimizer_E.zero_grad()
        self.backward_E()
        #if k % 1 == 0:
        self.optimizer_E.step()
        #    self.optimizer_E.zero_grad()
            
    def update_G(self, image_a, image_b, k): 
        self.set_requires_grad(self.dis, False)
        self.set_requires_grad(self.disC, False)
        self.AdjustmentNet.fpn.unfreeze()
        self.forward(image_a, image_b)  
        self.optimizer_G.zero_grad()
        self.backward_G()
        #if (k+1) % 8 == 0:
        self.optimizer_G.step()  

            #print('Optimized G!')
    def resume(self, model_dir, train=True):
        checkpoint = torch.load(model_dir)
        print(checkpoint.keys())
        if train:
            self.dis.load_state_dict(checkpoint['dis'])
            self.disC.load_state_dict(checkpoint['disC'])
        self.AdjustmentNet.load_state_dict(checkpoint['AdjustmentNet'])
        self.DecomNet.load_state_dict(checkpoint['DecomNet'])
        self.EnhanceNet.load_state_dict(checkpoint['EnhanceNet'])
        if train:
            self.optimizer_G.load_state_dict(checkpoint['optimizer_G'])
            self.optimizer_D.load_state_dict(checkpoint['optimizer_D'])
            self.optimizer_E.load_state_dict(checkpoint['optimizer_E'])
            self.optimizer_H.load_state_dict(checkpoint['optimizer_H'])
        return checkpoint['ep'], checkpoint['total_it']

    def save(self, filename, ep, total_it):
        state = {
                 'dis': self.dis.state_dict(),
                 'disC': self.disC.state_dict(),
                 'AdjustmentNet': self.AdjustmentNet.state_dict(),
                 'optimizer_G': self.optimizer_G.state_dict(),
                 'DecomNet': self.DecomNet.state_dict(),
                 'EnhanceNet': self.EnhanceNet.state_dict(),
                 'optimizer_D': self.optimizer_D.state_dict(),
                 'optimizer_E': self.optimizer_E.state_dict(),
                 'optimizer_H': self.optimizer_H.state_dict(),
                 'ep': ep,
                 'total_it': total_it
                  }
        torch.save(state, filename)
        return

    def assemble_outputs(self):
        images_a = self.normalize_image(self.R/2 + 0.5).detach()
        images_b = self.normalize_image(self.Lstd/2 + 0.5).detach()
        images_a1 = self.normalize_image(self.adjustLow/2+0.5).detach()
        images_b1 = self.normalize_image(self.Lad/2+0.5).detach()     
        images_a2 = self.normalize_image(self.low/2+0.5).detach()
        images_b2 = self.normalize_image(self.L/2+0.5).detach() 

        row1 = torch.cat((images_a[0:1, ::], images_a1[0:1, ::], images_a2[0:1, ::]), 3)
        row2 = torch.cat((images_b[0:1, ::], images_b1[0:1, ::], images_b2[0:1, ::]), 3)
        return torch.cat((row1,row2),2)

    def normalize_image(self, x):
        return x[:,0:3,:,:]
